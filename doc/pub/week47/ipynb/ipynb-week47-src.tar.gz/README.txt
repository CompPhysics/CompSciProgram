This IPython notebook week47.ipynb does not require any additional
programs.
