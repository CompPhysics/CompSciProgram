This IPython notebook week10.ipynb does not require any additional
programs.
