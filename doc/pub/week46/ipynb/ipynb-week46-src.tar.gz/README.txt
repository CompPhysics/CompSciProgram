This IPython notebook week46.ipynb does not require any additional
programs.
