This IPython notebook week7.ipynb does not require any additional
programs.
