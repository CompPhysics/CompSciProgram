This IPython notebook week50.ipynb does not require any additional
programs.
