This IPython notebook week45.ipynb does not require any additional
programs.
